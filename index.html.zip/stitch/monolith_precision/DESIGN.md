```markdown
# Design System Document: The Monolith & The Blade

## 1. Overview & Creative North Star: "Precision Monolith"
The Creative North Star for this design system is **"Precision Monolith."** It is an aesthetic rooted in the architectural permanence of a gallery and the technical precision of a high-performance engine. We are moving away from the "web-as-a-document" approach and toward "web-as-an-object."

This system breaks the "template" look through **Industrial Asymmetry**. We do not center everything; we use extreme horizontal tracking and wide-set typography to create an expansive, cinematic field of view. By utilizing the sharpest edges (0px border radius) and high-contrast tonal shifts, we mirror the silhouette of a bespoke luxury vehicle: intimidating, flawless, and undeniably premium.

---

## 2. Colors: Tonal Architecture
The palette is a study in darkness and light. We use depth to imply value.

### The "No-Line" Rule
**Explicit Instruction:** Do not use 1px solid borders to define sections. Traditional dividers are the mark of a template. Structure must be defined solely through background shifts.
*   **Example:** A `surface-container-low` (#1C1B1B) section should sit directly against a `surface` (#131313) background. The subtle 1% shift in luminosity is enough for the discerning eye.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers of polished obsidian and brushed steel.
*   **Base:** `surface` (#131313) or `surface-container-lowest` (#0E0E0E) for maximum depth.
*   **Secondary Layers:** Use `surface-container-low` (#1C1B1B) for large content blocks.
*   **Interactive Elements:** Use `surface-container-high` (#2A2A2A) to bring actionable items closer to the user.

### The "Glass & Metallic" Rule
To capture the "Porsche-inspired" sleekness, use Glassmorphism for floating navigation and overlays. Use a `surface` color with 60% opacity and a `backdrop-filter: blur(20px)`. 
*   **Signature Textures:** Apply a subtle linear gradient to `primary` (#FFFFFF) CTAs, transitioning from #FFFFFF to `secondary-fixed-dim` (#ADABAA) at a 45-degree angle to mimic the sheen of chrome.

---

## 3. Typography: The Editorial Voice
We use **Inter** with intentional, wide-set letter spacing to create a high-end editorial feel.

*   **Display (Large/Medium/Small):** These are your "Hero" statements. Use `-0.02em` tracking and `700` weight. For specific sub-headers, use uppercase with `0.15em` tracking to evoke luxury automotive branding.
*   **Headlines & Titles:** Used for technical specs and configuration headers. Maintain a strict hierarchy; if a headline is `headline-lg`, the supporting text must skip a level to `body-md` to create high-contrast negative space.
*   **Body:** Keep it lean. Use `body-md` for description blocks. Luxury is about what you *don't* say.
*   **Labels:** Use `label-sm` in all-caps for technical metadata (e.g., "0-60 MPH: 2.4S"), utilizing the `outline` color (#919191).

---

## 4. Elevation & Depth: Tonal Layering
In a world of sharp edges (0px radius), depth must be handled with extreme delicacy.

*   **The Layering Principle:** Avoid shadows entirely where possible. Place a `surface-container-highest` (#353534) card on a `surface-dim` (#131313) background. This creates "Natural Lift."
*   **Ambient Shadows:** If a floating element (like a customization drawer) requires a shadow, use a "Ghost Shadow": `0px 20px 50px rgba(0, 0, 0, 0.5)`. Never use harsh, dark shadows; they muddy the dark mode aesthetic.
*   **The "Ghost Border" Fallback:** If accessibility requires a container boundary, use the `outline-variant` (#474747) at **15% opacity**. It should be felt, not seen.
*   **Sharp Edges:** All containers, buttons, and inputs must have a **0px border-radius**. Sharp corners communicate precision and "The Blade" aesthetic.

---

## 5. Components

### Buttons: The Interaction Points
*   **Primary:** `on-primary` text on `primary` (#FFFFFF) background. 0px radius. Hover state: Transition to `secondary` (#C8C6C5) with a 300ms ease-out.
*   **Secondary (Ghost):** `primary` text with a 1px "Ghost Border" (outline-variant at 20%). 
*   **Tertiary:** Text only, uppercase, 0.1em letter spacing, with a 1px underline that expands from the center on hover.

### Input Fields: Technical Precision
*   **Styling:** No background fill. Only a bottom border (1px) using `outline-variant`. 
*   **States:** On focus, the bottom border transitions to `primary` (#FFFFFF). Helper text must be `label-sm` in `secondary` color.

### Cards & Lists: The Gallery View
*   **Rule:** Forbid the use of divider lines. 
*   **Layout:** Use the Spacing Scale `12` (4rem) to separate list items. 
*   **Hover:** List items should shift from `surface` to `surface-container-low` on hover to indicate interactivity.

### Additional Signature Component: The "Spec-Sheet" Drawer
A glassmorphic slide-out panel (`surface` @ 70% opacity + blur) used for selecting upholstery, alloys, or finishes. It should feel like a physical tray of materials being slid across a dark table.

---

## 6. Do's and Don'ts

### Do:
*   **Embrace Negative Space:** If you think there is enough room, add 20% more. Space is the ultimate luxury.
*   **Use Asymmetry:** Place high-contrast imagery on one side and wide-set typography on the other, off-center.
*   **Smooth Transitions:** Every state change (hover, click, page transition) must be a smooth, timed fade or slide.

### Don't:
*   **No Rounded Corners:** Never use a border-radius. It breaks the "Precision Monolith" language.
*   **No Generic Grids:** Avoid the "3-column card" layout. Try overlapping a `surface-container` over a full-width image.
*   **No Pure Greys:** Avoid using mid-tone greys that feel like default software. Stick to the deep blacks of the `surface` tokens or the bright silvers of the `primary` tokens.
*   **No Standard Shadows:** Never use the default "Drop Shadow" preset in your design tool. If it’s not ambient and tinted, don't use it.